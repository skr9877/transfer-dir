package com.example.bpmdemo;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.DeserializationFeature;
import org.flowable.rest.service.api.RestResponseFactory;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

@Configuration
public class FlowableConfig {

    @Bean
    public ObjectMapper objectMapper() {
        ObjectMapper mapper = new ObjectMapper();
        // JSON에 모르는 속성이 있어도 에러 내지 마라는 설정 (BPM 돌릴 때 안전함)
        mapper.configure(DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES, false);
        return mapper;
    }

    @Bean
    public RestResponseFactory restResponseFactory(ObjectMapper objectMapper) {
        // 위에서 만든 objectMapper를 받아서 공장에 넣어줍니다.
        return new RestResponseFactory(objectMapper);
    }
}