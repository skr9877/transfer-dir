package com.example.bpmdemo;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.scheduling.annotation.EnableScheduling;

@SpringBootApplication
@EnableScheduling
// 형님 패키지랑 flowable api 패키지를 동시에 스캔합니다.
@ComponentScan(basePackages = {
        "com.example.bpmdemo",
        "org.flowable.rest.service.api"
})
public class BpmFlowableDemoApplication {

    public static void main(String[] args) {
        SpringApplication.run(BpmFlowableDemoApplication.class, args);
    }

}
