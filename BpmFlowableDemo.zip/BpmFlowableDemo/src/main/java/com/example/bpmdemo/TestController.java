package com.example.bpmdemo;

import org.flowable.engine.RuntimeService;
import org.flowable.engine.TaskService;
import org.flowable.task.api.Task;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;
import java.util.stream.Collectors;

@RestController
public class TestController {

    @Autowired
    private RuntimeService runtimeService;

    @Autowired
    private TaskService taskService;

    // 1. 프로세스 강제 시작
    @GetMapping("/start")
    public String startProcess() {
        // hello.bpmn20.xml에 적힌 id가 "helloProcess"여야 합니다.
        runtimeService.startProcessInstanceByKey("helloProcess");
        return "🚀 프로세스가 시작되었습니다! DB를 확인하세요.";
    }

    // 2. 현재 대기 중인 할 일(Task) 목록 보기
    @GetMapping("/tasks")
    public List<String> getTasks() {
        List<Task> tasks = taskService.createTaskQuery().list();
        return tasks.stream()
                .map(task -> "할일: " + task.getName() + ", ID: " + task.getId())
                .collect(Collectors.toList());
    }
}