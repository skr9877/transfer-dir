package com.example.bpmdemo;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.scheduling.annotation.EnableScheduling;

@SpringBootApplication
@EnableScheduling
public class BpmDemoApplication {

    public static void main(String[] args) {
        SpringApplication.run(BpmDemoApplication.class, args);
    }

}
